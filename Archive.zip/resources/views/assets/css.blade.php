<!-- PICK ONE OF THE STYLES BELOW -->
	<link href="{{ asset('/') }}css/modern.css" rel="stylesheet">
	{{-- <link href="{{ asset('/') }}css/classic.css" rel="stylesheet"> --}}
	{{-- <link href="{{ asset('/') }}css/dark.css" rel="stylesheet"> --}}
	{{-- <link href="{{ asset('/') }}css/light.css" rel="stylesheet"> --}}

	<!-- BEGIN SETTINGS -->
	<!-- You can remove this after picking a style -->
	<style>
		body {
			opacity: 0;
		}
	</style>
	<script src="{{ asset('/') }}js/settings.js"></script>